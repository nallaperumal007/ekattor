<?php

namespace Botble\Dashboard\Events;

use Botble\Base\Events\Event;
use Illuminate\Foundation\Events\Dispatchable;

class RenderingDashboardWidgets extends Event
{
    use Dispatchable;
}
