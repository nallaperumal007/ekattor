<x-core::form-group {{ $attributes }}>
    {{ $slot }}
</x-core::form-group>
